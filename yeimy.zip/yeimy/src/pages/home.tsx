import { motion, useScroll, useTransform } from "framer-motion";
import { useRef, useEffect, useState } from "react";
import FadeIn from "@/components/FadeIn";
import ParticleBackground from "@/components/ParticleBackground";
import { Heart, Sparkles, Stars } from "lucide-react";

export default function Home() {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end end"]
  });

  const heroOpacity = useTransform(scrollYProgress, [0, 0.2], [1, 0]);
  const heroScale = useTransform(scrollYProgress, [0, 0.2], [1, 0.95]);

  return (
    <div ref={containerRef} className="relative min-h-[100dvh] w-full bg-background overflow-hidden text-foreground">
      <ParticleBackground />

      {/* Hero Section */}
      <motion.section 
        style={{ opacity: heroOpacity, scale: heroScale }}
        className="relative h-[100dvh] w-full flex flex-col items-center justify-center text-center px-4 z-10"
      >
        <div className="absolute inset-0 z-0">
          <img 
            src="/shimmer.png" 
            alt="Golden shimmer background" 
            className="w-full h-full object-cover opacity-40 mix-blend-screen"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-background/80 to-background" />
        </div>
        
        <div className="z-10 flex flex-col items-center max-w-4xl mx-auto mt-12">
          <FadeIn delay={0.2} className="mb-6">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-primary/30 bg-primary/10 backdrop-blur-sm text-primary text-sm tracking-[0.2em] uppercase font-sans">
              <Sparkles className="w-4 h-4" />
              <span>12 de Abril, 2026</span>
              <Sparkles className="w-4 h-4" />
            </div>
          </FadeIn>
          
          <FadeIn delay={0.5}>
            <h1 className="text-5xl md:text-7xl lg:text-8xl font-serif font-bold tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-[#F5C842] via-[#FFFFF0] to-[#D4A017] mb-4 drop-shadow-sm leading-tight pb-2">
              ¡Feliz Cumpleaños
              <br />
              <span className="italic font-light">Yeimy!</span>
            </h1>
          </FadeIn>
          
          <FadeIn delay={0.8}>
            <p className="text-2xl md:text-4xl font-serif text-accent italic tracking-wide mt-4">
              18 años de luz y magia
            </p>
          </FadeIn>

          <FadeIn delay={1.5} className="absolute bottom-12 animate-bounce">
            <div className="text-muted-foreground/60 flex flex-col items-center gap-2 font-sans text-sm uppercase tracking-widest">
              <span>Desliza hacia abajo</span>
              <div className="w-[1px] h-12 bg-gradient-to-b from-muted-foreground/60 to-transparent" />
            </div>
          </FadeIn>
        </div>
      </motion.section>

      {/* Intro Quote Section */}
      <section className="relative min-h-[70vh] flex items-center justify-center py-24 px-6 z-10">
        <div className="max-w-3xl mx-auto text-center">
          <FadeIn>
            <Stars className="w-8 h-8 text-primary mx-auto mb-8 opacity-70" />
            <h2 className="text-3xl md:text-5xl font-serif font-light leading-relaxed text-foreground/90">
              "Hoy comienza un nuevo capítulo. Un salto hacia la adultez, lleno de promesas, sueños y una belleza que solo tú posees."
            </h2>
            <div className="w-24 h-[1px] bg-primary/40 mx-auto mt-12" />
          </FadeIn>
        </div>
      </section>

      {/* Secret Garden Section */}
      <section className="relative py-32 px-4 z-10">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center gap-16">
          <FadeIn className="flex-1 w-full" direction="right">
            <div className="relative rounded-2xl overflow-hidden shadow-2xl ring-1 ring-primary/20 aspect-[4/5] md:aspect-square">
              <img 
                src="/garden.png" 
                alt="Secret midnight garden" 
                className="w-full h-full object-cover transition-transform duration-1000 hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent opacity-80" />
            </div>
          </FadeIn>
          
          <div className="flex-1 w-full space-y-8 text-center md:text-left">
            <FadeIn delay={0.2} direction="left">
              <h3 className="text-4xl md:text-5xl font-serif text-primary">Un alma radiante</h3>
            </FadeIn>
            <FadeIn delay={0.4} direction="left">
              <p className="text-lg md:text-xl font-sans text-muted-foreground leading-relaxed font-light">
                Entrar en los 18 es como abrir la puerta a un jardín secreto a medianoche. Hay misterio, hay elegancia y, sobre todo, hay una luz cálida que te guía.
              </p>
            </FadeIn>
            <FadeIn delay={0.6} direction="left">
              <p className="text-lg md:text-xl font-sans text-muted-foreground leading-relaxed font-light">
                Tu calidez, tu risa y tu forma de ver el mundo iluminan cada habitación en la que entras, como el brillo de una vela en la oscuridad.
              </p>
            </FadeIn>
          </div>
        </div>
      </section>

      {/* Elegance Section */}
      <section className="relative py-32 px-4 z-10 bg-secondary/10 border-y border-secondary/30">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row-reverse items-center gap-16">
          <FadeIn className="flex-1 w-full" direction="left">
            <div className="relative rounded-2xl overflow-hidden shadow-2xl ring-1 ring-accent/20 aspect-[3/4]">
              <img 
                src="/flowers.png" 
                alt="Elegant terracotta flowers" 
                className="w-full h-full object-cover transition-transform duration-1000 hover:scale-105"
              />
            </div>
          </FadeIn>
          
          <div className="flex-1 w-full space-y-8 text-center md:text-left">
            <FadeIn delay={0.2} direction="right">
              <h3 className="text-4xl md:text-5xl font-serif text-accent">Tu florecer</h3>
            </FadeIn>
            <FadeIn delay={0.4} direction="right">
              <p className="text-lg md:text-xl font-sans text-muted-foreground leading-relaxed font-light">
                Que esta nueva etapa te traiga la confianza para ser exactamente quien quieres ser. Eres fuerte, hermosa y capaz de lograr todo lo que te propongas.
              </p>
            </FadeIn>
            <FadeIn delay={0.6} direction="right">
              <p className="text-lg md:text-xl font-sans text-muted-foreground leading-relaxed font-light">
                Celebro tu vida hoy y siempre. Que nunca falte esa chispa dorada en tus ojos.
              </p>
            </FadeIn>
          </div>
        </div>
      </section>

      {/* Wishes Grid */}
      <section className="relative py-32 px-4 z-10">
        <div className="max-w-5xl mx-auto">
          <FadeIn className="text-center mb-16">
            <h3 className="text-3xl md:text-5xl font-serif text-primary">Mis deseos para ti</h3>
          </FadeIn>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { title: "Amor Infinito", desc: "Que siempre estés rodeada de personas que valoren la joya que eres." },
              { title: "Aventuras", desc: "Que cada día sea una oportunidad para descubrir algo maravilloso." },
              { title: "Paz y Brillo", desc: "Que tu corazón siempre encuentre refugio y tu alma nunca deje de brillar." }
            ].map((wish, i) => (
              <FadeIn key={i} delay={0.2 * i} direction="up">
                <div className="bg-card/50 backdrop-blur-sm border border-border/50 p-8 rounded-2xl text-center h-full hover:bg-card/80 transition-colors duration-500">
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-6">
                    <Heart className="w-6 h-6 text-primary" />
                  </div>
                  <h4 className="text-2xl font-serif text-foreground mb-4">{wish.title}</h4>
                  <p className="text-muted-foreground font-sans font-light leading-relaxed">{wish.desc}</p>
                </div>
              </FadeIn>
            ))}
          </div>
        </div>
      </section>

      {/* Footer / Outro */}
      <section className="relative min-h-[60vh] flex flex-col items-center justify-center py-24 px-6 z-10 text-center">
        <FadeIn>
          <div className="w-px h-24 bg-gradient-to-b from-transparent via-primary/50 to-primary/10 mx-auto mb-12" />
          <h2 className="text-4xl md:text-6xl font-serif text-transparent bg-clip-text bg-gradient-to-r from-accent via-[#FFFFF0] to-primary drop-shadow-md mb-8">
            Te quiero muchísimo.
          </h2>
          <p className="text-xl md:text-2xl font-serif italic text-muted-foreground">
            Disfruta tu día, reina.
          </p>
        </FadeIn>
      </section>
    </div>
  );
}
